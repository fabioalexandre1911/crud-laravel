<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Inscrito extends Model
{
    use HasFactory;

    /**
     * The model's default values for fillable.
     *
     * @var array
     */
    protected $fillable = ["nome","cpf","email","evento_id","status"];

    
}
