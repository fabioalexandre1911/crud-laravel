<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Inscrito;

class InscritoController extends Controller
{
    public function index()
    {
        $inscritos= Inscrito::all(); 

        return view('evento', ['inscritos'=>$inscritos]);


       
    }

    public function salvar(Request $request)
    {
       // dd ($request->all());
        Inscrito::create( $request->all() );

        return redirect('/inscricao')->with('status', 'Inscrito com Sucesso!');
        // Meu melhor amigo dd

        // Criar um model
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request_)

    {
        $parans= $request_->all();
        Inscrito::find($parans['id'])->delete();

        return redirect('/inscricao')->with('status', 'Excluído com Sucesso!');
    }

    // public function edit($id)
    // {
    //     $parans_= $id->all();
    //     Inscrito::find($parans_['id']);
        
    //     return view("/inscricao",['inscrito'=>$id])->with('status', 'Editado com Sucesso!');
    // }

}
