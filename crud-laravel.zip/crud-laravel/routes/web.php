<?php

use App\Http\Controllers\InscritoController;
use Illuminate\Support\Facades\Route;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/inscricao', [InscritoController::class, 'index']);
Route::post('/inscricao', [InscritoController::class, 'salvar']);
//Route::get('/inscricao', [InscritoController::class, 'edit']);
Route::delete('/inscricao', [InscritoController::class, 'destroy']);


