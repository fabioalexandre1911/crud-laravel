<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Sistema de Inscrições em eventos </title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    </head>
    <body class="sb-nav-fixed">
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                                  <?php if(session('status')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('status')); ?>

                                </div>
                                     <?php endif; ?>
                       
                        <div class="card mb-4 border-primary">
                            <div class="card-header bg-gradient bg-primary">
                                <i class="fas fa-table me-1"></i>
                                Formulário
                            </div>
                            <div class="card-body">
                                <div class="container">
                                    <div class="row">
                                        <div class="">
                                            <div class="p-2 mb-1 bg-body-tertiary rounded-3">
                                               
                                                                           
                                                    <form action="/inscricao" method="POST" name="form">
                                                        <?php echo csrf_field(); ?>
                                                        <div class="row">

                                                            <div class="col-md-6">    
                                                                <div class="input-group mb-3">
                                                                    <span class="input-group-text" id="basic-addon1"><span class="iconify" data-icon="lucide:boxes"></span></span>
                                                                    <input type="text" class="form-control" placeholder="NOME" name="nome">
                                                                </div>
                                                            </div>

                                                            <div class="col-md-6">
                                                                <div class="input-group mb-3 col-6">
                                                                    <span class="input-group-text iconify" id="basic-addon1"><span class="iconify" data-icon="material-symbols:barcode"></span></span>
                                                                    <input type="text" class="form-control" placeholder="CPF" name="cpf">
                                                                    <span class="iconify" ></span>
                                                                </div>
                                                            </div>

                                                            <div class="col-md-6">    
                                                                <div class="input-group mb-3">
                                                                    <span class="input-group-text" id="basic-addon1"><span class="iconify" data-icon="healthicons:stock-out-negative"></span></span>
                                                                    <input type="email" class="form-control" placeholder="EMAIL" name="email">
                                                                </div>
                                                            </div>
                                                            
                                                            
                                                            
                                                            <div class="col-md-6">    
                                                                <div class="input-group mb-3">
                                                                    <span class="input-group-text" id="basic-addon1"><span class="iconify" data-icon="solar:tag-price-bold"></span></span>
                                                                    <select class="input-group-text" name="evento_id" id="evento_id">
                                                                        <option value="">Selecione</option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <button type="submit" class="btn btn-outline-primary" type="button" name="submit">Cadastrar</button>
                                                    </form>
                                               
                                                </div><hr>
                                               <h3>Lista de Inscritos</h3>
                                                <div class="col-md-12">  
                                                <table id="datatablesSimple" >
                                                    <thead >
                                                        <tr class="text-center">
                                                            <th>Nome</th>
                                                            <th>CPF</th>
                                                            <th>Email</th>
                                                            <th>Evento</th>
                                                            <th>Status</th>
                                                            <th>Ações</th>
                                                            
                                                        </tr>
                                                    </thead>
                                                    
                                                    <tbody>
                                                        <?php $__currentLoopData = $inscritos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inscrito): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td class="align-middle"><?php echo e($inscrito->nome); ?></td>
                                                            <td class="align-middle"><?php echo e($inscrito->cpf); ?></td>
                                                            <td class="align-middle"><?php echo e($inscrito->email); ?></td>
                                                            <td class="align-middle"><?php echo e($inscrito->evento_id); ?></td>
                                                            <td><p class="text-center"><?php echo e($inscrito->status); ?></td>
                                                            <td>
                                                                <form action="/inscricao" method="POST" style="float: left">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('DELETE'); ?>
                                                                    <input type="hidden" name="id" value="<?php echo e($inscrito->id); ?>">
                                                                   <button type="submit" class="btn btn-sm btn-danger" data-bs-target="#excluir"><span class="iconify" data-icon="bi:trash-fill"></span></button> </form> 
                                                                   
                                                                   <a href="/inscricao/<?php echo e($inscrito->id); ?>">
                                                                    <input type="hidden" name="id" value="<?php echo e($inscrito->id); ?>">
                                                                   <button style="margin-left:10px" class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#editar"><span class="iconify" data-icon="ph:pencil-bold"></span></button>    
                                                                </a>
                                                                   </td>
                                                                
                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                                         </div>
                                                    </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    
                </main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            
                        </div>
                    </div>
                </footer>
            </div>
        </div> 
        <script  src="https://code.jquery.com/jquery-3.7.1.js"
  integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="http://localhost/project/js/scripts.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
        <script src="http://localhost/project/js/datatables-simple-demo.js"></script>
        <script src="https://code.iconify.design/3/3.1.0/iconify.min.js"></script>
        <script>
                
            $(document).ready(function() {
                $.get( "https://demo.ws.itarget.com.br/event.php", function( data ) {
                   console.log(data.data)
                   var eventos =  data.data
                    $.each(eventos, function (key, evento) {
                        console.log(evento) 
                        if (evento.status) {

                            $('#evento_id').append('<option value=' + evento.id + '>' + evento.name + '</option>');

                        }
                           
                    });                
                });  
            });                    
        </script>
      
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel-my-app\crud\resources\views/evento.blade.php ENDPATH**/ ?>